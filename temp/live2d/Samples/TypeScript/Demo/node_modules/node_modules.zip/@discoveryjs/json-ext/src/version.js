module.exports = require('../package.json').version;
