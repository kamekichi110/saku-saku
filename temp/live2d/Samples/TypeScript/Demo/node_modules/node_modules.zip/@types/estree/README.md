# Installation
> `npm install --save @types/estree`

# Summary
This package contains type definitions for estree (https://github.com/estree/estree).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/estree.

### Additional Details
 * Last updated: Wed, 19 Apr 2023 05:02:44 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [RReverser](https://github.com/RReverser).
