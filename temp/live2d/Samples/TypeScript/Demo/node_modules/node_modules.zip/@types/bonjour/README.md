# Installation
> `npm install --save @types/bonjour`

# Summary
This package contains type definitions for bonjour (https://github.com/watson/bonjour).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bonjour.

### Additional Details
 * Last updated: Thu, 23 Dec 2021 23:34:20 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)
 * Global values: none

# Credits
These definitions were written by [Quentin Lampin](https://github.com/quentin-ol).
