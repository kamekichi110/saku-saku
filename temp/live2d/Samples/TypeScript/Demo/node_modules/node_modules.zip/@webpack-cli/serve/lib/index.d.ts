import { IWebpackCLI } from "webpack-cli";
declare class ServeCommand {
    apply(cli: IWebpackCLI): Promise<void>;
}
export default ServeCommand;
